﻿namespace Telephony.Core
{
    public interface IEngine
    {
        void Start();
    }
}
