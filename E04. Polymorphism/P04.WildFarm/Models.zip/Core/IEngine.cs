﻿namespace P04.WildFarm.Core
{
    public interface IEngine
    {
        void Start();
    }
}
