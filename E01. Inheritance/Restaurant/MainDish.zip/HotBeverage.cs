﻿namespace Restaurant
{
    public class HotBeverage : Beverage
    {
        //On initialization <=> Constuctor
        public HotBeverage(string name, decimal price, double milliliters)
            : base(name, price, milliliters)
        {

        }
    }
}
